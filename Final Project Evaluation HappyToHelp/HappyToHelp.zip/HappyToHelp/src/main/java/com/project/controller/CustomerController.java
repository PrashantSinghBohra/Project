package com.project.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.RequestMatchResult;

import com.project.dao.BookingDao;
import com.project.dao.CustomerDao;
import com.project.dao.ServiceDao;
import com.project.entity.BookingInfoTbl;
import com.project.entity.CustomerInfoTbl;
import com.project.entity.ServiceInfoTbl;

@Controller
@SessionAttributes("currentcustomer")
public class CustomerController {

	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private ServiceDao serviceDao;

	@Autowired
	private BookingDao bookingDao;

	
	
	@GetMapping("/customerregistration")
	public String func1()
	{
		System.out.println("Reached in func1");
		return "signupCustomer";
	}

	
	@GetMapping("/index")
	public String homePage()
	{
		
		return "index";
	}
	
	@PostMapping("/addingcustomer")
	public ModelAndView addCustomer(@RequestParam String first_name,
			@RequestParam String  lname,
			@RequestParam String mobileNo,
			@RequestParam String email,
			@RequestParam String username,
			@RequestParam String password,
			@RequestParam String address,
			@RequestParam String state,
			@RequestParam String city,
			@RequestParam int pincode
			)
	{
		System.out.println("Reached in addProduct");
		ModelAndView mv = new ModelAndView();
		customerDao.addCustomer(first_name, lname, mobileNo, email, username, password, address, state, city, pincode);
		mv.addObject("message","Registration Successfull");
		mv.setViewName("LoginCustomer");
		return mv;
	}

	@GetMapping("/Login")
	public ModelAndView loginCustomer()
	{
		ModelAndView mv = new ModelAndView();

		 mv.setViewName("LoginCustomer"); 
		 return mv;
		 
	}

	@PostMapping("/LoginCustomer")
	public ModelAndView loginCustomer(@RequestParam String email,@RequestParam String password ,HttpServletRequest request) 
	{
		HttpSession session = request.getSession();
		System.out.println("Session ID : " + session.getId());
		ModelAndView mv = new ModelAndView();
		CustomerInfoTbl customer = customerDao.authenticationCustomer(email,
				password);

		if(Objects.isNull(customer))
		{
			mv.setViewName("LoginCustomer");	
		}
		if(Objects.nonNull(customer))
		{
			List<ServiceInfoTbl> services =   serviceDao.getAllServices();
			
			mv.addObject("services",services);
			mv.addObject("customer",customer);
			session.setAttribute("currentcustomer", customer);
			
			mv.setViewName("Customer_searchview");
		}	
		return mv; 
	}

	@GetMapping("/showAllServices")
	public ModelAndView showAllServices(int custid)
	{
		ModelAndView mv = new ModelAndView();
		
		int count = bookingDao.numberOfOrders(custid);
		List<ServiceInfoTbl> services =   serviceDao.getAllServices();
		
		CustomerInfoTbl customer = customerDao.findById(custid);
		List<BookingInfoTbl> bookings =   bookingDao.showBooking(custid);
		
		mv.addObject("orderscount",count);
		mv.addObject("bookings", bookings);
		mv.addObject("services", services);
		mv.addObject("customer", customer);
		mv.setViewName("Customer");
		return mv;
	}

	@GetMapping("/logout")
	public ModelAndView logout(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		System.out.println(session.getId());
		session.invalidate();
		request.getSession(false);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LoginCustomer");
		return mv;
	}

	@PostMapping("/bookService")
	public ModelAndView bookService(@RequestParam int serviceid,@RequestParam int custid,@RequestParam String date) throws ParseException 
	{
		ModelAndView mv = new ModelAndView();
		System.out.println("Passed :" + date);
		
		CustomerInfoTbl cust = customerDao.findById(custid);
		ServiceInfoTbl service = serviceDao.findById(serviceid);
		List<ServiceInfoTbl> services = serviceDao.getAllServices();
		
		BookingInfoTbl defaults = new BookingInfoTbl();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		Date date1 = dateFormat.parse(date);
		BookingInfoTbl book = new BookingInfoTbl(new Date(), service.getService_Cost(),date1,defaults.getBooking_Status(), null, null,0, cust, service);
		bookingDao.saveBooking(book);
		
		mv.addObject("customer",cust);
		mv.addObject("services", services);
		
		mv.setViewName("Customer_searchview");
		return mv;
	}

	@GetMapping("/showservices")
	public ModelAndView showServices(@RequestParam int custid)
	{
		ModelAndView mv = new ModelAndView();
		CustomerInfoTbl customer = customerDao.findById(custid);
		List<ServiceInfoTbl> services = serviceDao.getAllServices();
		mv.addObject("services", services);
		mv.addObject("customer",customer);
		mv.setViewName("Customer_searchview");
		return mv;
		
		
	}
	
	
	@GetMapping("/search")
	public String searchByName()
	{

		return "Search";

	}


	@PostMapping("/searchService")
	public ModelAndView searchedServices(@RequestParam String name)
	{
		ModelAndView mv = new ModelAndView();
		List<ServiceInfoTbl> services = serviceDao.findByName(name);
		mv.addObject("services",services);
		mv.setViewName("Services");

		return mv;
	}


	@GetMapping("/editprofile")
	public ModelAndView editProfile()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Customer_ediprofile");
		return mv;

	}

	@PostMapping("/editprofiledetails")
	public String updateProfile(
			@RequestParam String first_name,
			@RequestParam String  lname,
			@RequestParam String mobileNo,
			@RequestParam String email,
			@RequestParam String username,
			@RequestParam String password,
			@RequestParam String address,
			@RequestParam String state,
			@RequestParam String city,
			@RequestParam int pincode,
			
			HttpServletRequest request
			
			)
	{
		
		CustomerInfoTbl customer = (CustomerInfoTbl) request.getSession().getAttribute("currentcustomer");
		customer.setCustomer_Address(address);
		customer.setCustomer_City(city);
		customer.setCustomer_EmailId(email);
		customer.setCustomer_FirstName(first_name);
		customer.setCustomer_LastName(lname);
		customer.setCustomer_MobileNo(mobileNo);
		customer.setCustomer_UserName(username);
		customer.setCustomer_State(state);
		customer.setCustomer_Password(password);
		customer.setCustomer_Pincode(pincode);

		customerDao.updateCustomer(customer);
		return "Customer_ediprofile";

	}
	
	@GetMapping("/feedback")
	public String giveFeedback(@RequestParam int serviceid,@RequestParam int custid,  Model mv )
	{
	
		ServiceInfoTbl service = serviceDao.findById(serviceid);
		CustomerInfoTbl customer = customerDao.findById(custid);
		List<BookingInfoTbl> bookings = bookingDao.showBooking(custid);
		mv.addAttribute("bookings",bookings);
		mv.addAttribute("customer", customer);
		mv.addAttribute("serviceobject",service);
		return "Customer_feedback";
		
	}
	
	
	@PostMapping("/insertfeedback")
	public String insertFeedback(@RequestParam int rating,@RequestParam  String comment ,@RequestParam int custid,@RequestParam int serviceid,Model mv)
	{
		ServiceInfoTbl service = serviceDao.findById(serviceid);
		List<BookingInfoTbl> booking = bookingDao.showBooking(custid);
		CustomerInfoTbl customer = customerDao.findById(custid);
		mv.addAttribute("customer", customer);
		mv.addAttribute("serviceobject",service);
		mv.addAttribute("bookings",booking);
		
		System.out.println(rating + "---- " + comment + "-cust-- " + custid + "-ser-- " + serviceid);
		
		List<BookingInfoTbl> bookings = bookingDao.updateBooking(custid,serviceid);
		
		for (BookingInfoTbl book : bookings) {
			book.setFeedBack_Comment(comment);
			book.setFeedback_Rating(rating);
			book.setFeedback_Date(new Date());
			bookingDao.saveBooking(book);
		}
		
		
		
		return "Customer_feedback";
		
	}
	

	
	
	
	



}
