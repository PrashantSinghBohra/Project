package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.entity.CustomerInfoTbl;
import com.project.entity.VendorInfoTbl;

@Repository
public interface VendorRepository extends JpaRepository<VendorInfoTbl, Integer> {

	@Query(value= "SELECT * FROM vendor_info_tbl U WHERE U.vendor_email_id=:email AND U.vendor_password=:password",nativeQuery=true  )
	public VendorInfoTbl loginVendor ( @Param ("email") String email, @Param ("password") String password);
	
	public VendorInfoTbl findByVendorid(int id);
	
	
}
