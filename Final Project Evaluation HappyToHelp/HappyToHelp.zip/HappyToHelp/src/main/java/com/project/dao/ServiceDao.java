package com.project.dao;

import java.sql.Blob;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.entity.ServiceInfoTbl;
import com.project.entity.VendorInfoTbl;
import com.project.repository.ServiceRepository;

@Service
public class ServiceDao {

	@Autowired
	private ServiceRepository serviceRepo;
	
	public List<ServiceInfoTbl> getAllServices()
	{
		
		return serviceRepo.findAll();
		
	}
	
	
	public ServiceInfoTbl findById(int id)
	{
		 Optional<ServiceInfoTbl> service =  serviceRepo.findById(id);
		 ServiceInfoTbl booked  =  service.get();
		 return booked;
		 
	}
	
	public List<ServiceInfoTbl> findByName(String name)
	{
		return serviceRepo.getByName(name);
	}
	
	
	
	public void addService(String name,int cost,int discount,int time,Blob image,VendorInfoTbl vendor )
	{

		ServiceInfoTbl services = new ServiceInfoTbl(cost, discount, image, name, time, vendor);
		serviceRepo.save(services);
	}


	public void deleteService(int serviceId) {
		
		ServiceInfoTbl service = serviceRepo.findById(serviceId).get();
		if(service != null)
		{
			serviceRepo.delete(service);
		}
	}

	
	
	
}
