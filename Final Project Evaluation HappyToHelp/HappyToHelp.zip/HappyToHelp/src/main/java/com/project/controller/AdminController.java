package com.project.controller;

import java.sql.Blob;
import java.io.IOException;
import java.sql.SQLException;
import com.project.dao.VendorDao;
import com.project.dao.ServiceDao;
import com.project.dao.CustomerDao;
import com.project.entity.ServiceInfoTbl;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;


@Controller
public class AdminController 
{
	@Autowired
	ServiceDao serviceDao;
	
	@Autowired
    VendorDao vendorDao;
	
    @Autowired
    CustomerDao customerDao;
    
    
    //------------------------------------------ Delete Service By ID
    @RequestMapping("/serviceDelete")
    public String serviceDeleteURL()
    {
    	return "ServiceVendor";
    }
    
    @RequestMapping("/delete")
    public ModelAndView serviceDelete(@RequestParam int serviceId)
    {
    	ModelAndView mv = new ModelAndView();
    	serviceDao.deleteService(serviceId);
        mv.setViewName("DeleteService");
    	return mv;
    }  
    
    //------------------------------------------ Delete Vendor By ID
    @RequestMapping("/vendorDelete")
    public String vendorDeleteURL()
    {
    	return "DeleteVendor";
    }
    
    @RequestMapping("/delete1")
    public ModelAndView vendorDelete(@RequestParam int vendorId)
    {
    	ModelAndView mv = new ModelAndView();
    	vendorDao.deleteVendor(vendorId);
        mv.setViewName("DeleteVendor");
    	return mv;
    }  
    
    
    //------------------------------------------ Delete Customer By ID
    @RequestMapping("/customerDelete")
    public String customerDeleteURL()
    {
    	return "DeleteCustomer";
    }
}  
    

		
