package com.project.emailservice;

import org.springframework.stereotype.Service;

import com.iet.sender.EmailSender;

@Service
public class EmailService
{
	public void sendSimpleEmail(String emails) 
	{  
	      try 
	      {
	    	   EmailSender email = new EmailSender("happytohelp.electronicservice@gmail.com","qjufebilnrblmqiy");
			   email.sendEmail(emails, "change your Password : http://localhost:8080/ResetPassword", "Reset your password");
		  } 
	      catch (Exception e) 
	      {
			   e.printStackTrace();
		  }
	 }
}
