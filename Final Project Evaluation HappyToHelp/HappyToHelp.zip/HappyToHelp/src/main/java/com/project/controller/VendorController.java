package com.project.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.project.dao.ServiceDao;
import com.project.dao.VendorDao;
import com.project.entity.CustomerInfoTbl;
import com.project.entity.VendorInfoTbl;




@Controller
@SessionAttributes("currentvendor")
public class VendorController {

	@Autowired
	private VendorDao vendorDao;


	@Autowired
	private ServiceDao serviceDao;

	@GetMapping("/vendorregistration")
	public String func1()
	{
		System.out.println("Reached in func1");
		return "signupVendor";
	}

	@PostMapping("/addingvendor")
	public String addVendor(@RequestParam String Vendor_FirstName, @RequestParam String Vendor_LastName,
			@RequestParam String Vendor_MobileNo, @RequestParam String Vendor_EmailId, 
			@RequestParam String Vendor_UserName, @RequestParam String Vendor_Password,
			@RequestParam String Vendor_Address, @RequestParam String Vendor_State,
			@RequestParam String Vendor_City, @RequestParam int Vendor_Pincode,
			@RequestParam("file") MultipartFile file)
	{
		byte[] byteArr;
		Blob blob;
		try 
		{
			byteArr = file.getBytes();
			blob = new SerialBlob(byteArr);
			vendorDao.addVendor(Vendor_FirstName, Vendor_LastName, Vendor_MobileNo, Vendor_EmailId, Vendor_UserName, Vendor_Password, Vendor_Address, Vendor_State, Vendor_City, Vendor_Pincode,blob);
		}
		catch (SQLException e) 
		{	
			e.printStackTrace();

		}
		catch (IOException e1)
		{
			e1.printStackTrace();

		}

		return "LoginVendor";
	}

	@RequestMapping("/home")
	public String showHome() {

		return "home";
	}


	@PostMapping("/getImage")
	public String verifyUser(Model model,@RequestParam int id) {

		VendorInfoTbl result = vendorDao.findVendorById(id);

		System.out.println(result);
		if(result != null) {

			model.addAttribute("image", result);
			return "home";
		}
		else {

			model.addAttribute("errormsg", "No image found !!");
			return "home";
		}
	}


	@GetMapping("/LoginVendor")
	public ModelAndView loginCustomer(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();

		mv.setViewName("LoginVendor"); 
		return mv;

	}

	@PostMapping("/VendorLogin")
	public ModelAndView loginCustomer(@RequestParam String email,@RequestParam String password ,HttpServletRequest request) 
	{
		HttpSession session = request.getSession();
		System.out.println("Session ID : " + session.getId());
		ModelAndView mv = new ModelAndView();
		VendorInfoTbl vendor = vendorDao.authenticationVendor(email, password);

		if(Objects.isNull(vendor))
		{
			mv.setViewName("LoginVendor");	
		}
		if(Objects.nonNull(vendor))
		{
			mv.addObject("vendor",vendor);
			session.setAttribute("currentvendor", vendor);
			mv.setViewName("VendorEditServices");
		}	
		return mv; 
	}

	@GetMapping("/addservice")
	public ModelAndView addService(@RequestParam int vendorid)
	{
		VendorInfoTbl vendor = vendorDao.findVendorById(vendorid);
		
		ModelAndView mv =new ModelAndView();
		mv.addObject("vendor", vendor);
		mv.setViewName("VendorAddService");
		
		return mv;

	}

	@PostMapping("/saveservice")
	public String saveService(@RequestParam String name,@RequestParam int cost,@RequestParam int discount,@RequestParam int time,@RequestParam("file") MultipartFile file,@RequestParam int vendorid,Model model)
	{
		
		byte[] byteArr;
		Blob blob;
		try 
		{
			byteArr = file.getBytes();
			blob = new SerialBlob(byteArr);
			System.out.println("Vendor Id : " + vendorid);
			VendorInfoTbl vendor = vendorDao.findVendorById(vendorid);
			serviceDao.addService(name, cost, discount, time, blob, vendor);
		}
		catch (SQLException e) 
		{	
			e.printStackTrace();

		}
		catch (IOException e1)
		{
			e1.printStackTrace();

		}
		VendorInfoTbl vendor = vendorDao.findVendorById(vendorid);
		model.addAttribute("vendor", vendor);
		return "VendorEditServices";
	}
	
	@GetMapping("/logoutVendor")
	public ModelAndView logout(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		System.out.println(session.getId());
		session.invalidate();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LoginVendor");
		return mv;
	}
	
	


}
