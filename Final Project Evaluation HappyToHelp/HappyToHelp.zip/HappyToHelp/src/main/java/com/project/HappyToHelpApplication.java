package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyToHelpApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyToHelpApplication.class, args);
	}

}
