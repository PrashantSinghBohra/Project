package com.project.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.dao.CustomerDao;
import com.project.emailservice.EmailService;
import com.project.entity.CustomerInfoTbl;

@Controller
public class EmailController
{
    @Autowired
    EmailService  emailService;
    
    @Autowired
    CustomerDao customerDao;
    
    @RequestMapping("/forgotPassword")
    public String emailReset()
    {
    	return "ResetPassword";
    }
    
    @GetMapping("ResetPassword")
    public String emailReturn()
    {
		return "ConfirmPassword";
    	
    }
    
    @PostMapping("/emailsender")
    public String emailSendToReset(@RequestParam String email)
    {
    	emailService.sendSimpleEmail(email);
    	return "ResetPassword";
    }
    
    
    @PostMapping("/resetPassword")
    public String Resetpassword(@RequestParam String email, @RequestParam String password1, @RequestParam String password2)
    {
    	
    	if(password1.equalsIgnoreCase(password2))
    	{
    	    CustomerInfoTbl customer =  customerDao.authenticationEmail(email);
    	      if(Objects.nonNull(customer))
    	      {
    	    	  customer.setCustomer_Password(password1);
    	    	  customerDao.updateCustomer(customer);
    	      }
    	}
    	
    	return "LoginCustomer";
    }
}
