package com.project.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.entity.BookingInfoTbl;
import com.project.repository.BookingRepository;

@Service
public class BookingDao {

	@Autowired
	private BookingRepository bookingRepo;
	
	
	public void saveBooking(BookingInfoTbl book)
	{
		bookingRepo.save(book);
		
	}
	
	public List<BookingInfoTbl> updateBooking(int custid,int serviceid)
	{	
		return bookingRepo.findByCustomerId(custid,serviceid);	
	}
	
	
	public List<BookingInfoTbl> showBooking(int id)
	{
		return bookingRepo.findListOfOrders(id);
	}
	
	
	
	
	
	public int numberOfOrders(int id)
	{
		
			return bookingRepo.numberOfOrders(id);
		
		
	}
}
