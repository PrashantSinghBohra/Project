package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.entity.BookingInfoTbl;


@Repository
public interface BookingRepository extends JpaRepository<BookingInfoTbl,Integer> {

	
	@Query(value="SELECT * FROM booking_info_tbl b WHERE b.booking_customer_id=:id AND b.booking_service_id=:serviceid",nativeQuery=true )
	public List<BookingInfoTbl> findByCustomerId(@Param("id") int id , @Param("serviceid") int serviceid );
	
	
	
	@Query(value="SELECT * FROM booking_info_tbl b WHERE b.booking_customer_id=:id ",nativeQuery=true )
	public List<BookingInfoTbl> findListOfOrders(@Param("id") int id );
	
	
	@Query(value="SELECT count(*) from booking_info_tbl b where  b.booking_customer_id=:id",nativeQuery = true)
	public int numberOfOrders(@Param("id") int id);

	
	
}
