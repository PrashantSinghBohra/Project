package com.project.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.project.dao.ServiceDao;
import com.project.entity.ServiceInfoTbl;



@Controller
public class ServiceController {

	@Autowired
	private ServiceDao serviceDao;
	
	
	@GetMapping("/services")
	public ModelAndView getAllServices(HttpServletRequest request)
	{
		ModelAndView model = new ModelAndView();
		List<ServiceInfoTbl> services = serviceDao.getAllServices();
		
		model.addObject("services", services);
		model.setViewName("Index");
		return model;
	}
	
	
	@PostMapping("/addservice") 
	public String addService(@RequestParam String name,@RequestParam int cost,@RequestParam int discount,@RequestParam int time,@RequestParam("file") MultipartFile file)
	{
		
		byte[] byteArr;
		Blob blob;
		try 
		{
			byteArr = file.getBytes();
			blob = new SerialBlob(byteArr);
			serviceDao.addService(name, cost, discount, time, blob, null);
		}
		catch (SQLException e) 
		{	
			e.printStackTrace();
			
		}
		catch (IOException e1)
		{
			e1.printStackTrace();
			
		}
		
		return "success";
		
	}
	
	
	@GetMapping("/service1")
	public String showServices()
	{
		return "service1";
	}
	
	@GetMapping("/Aboutus")
	public String showAboutUs()
	{
		return "Aboutus";
	}
	
	@GetMapping("/ContactUs")
	public String showContactUs()
	{
		return "ContactUs";
	}
	
	
	
	
}
